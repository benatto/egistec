#ifndef _VERSIONINFO_H_
#define _VERSIONINFO_H_

#define NAME_EGISDRIVER		"Egis Fingerprint Driver"
#define VERSION_EGISDRIVER	"1.0.5.0"

#define VERSION_DIGIT_EGISDRIVER	0x01000500		

#endif
